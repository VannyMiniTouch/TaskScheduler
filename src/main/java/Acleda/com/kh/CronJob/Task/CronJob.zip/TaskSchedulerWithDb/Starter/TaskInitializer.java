// package com.respapis.respApisCleint.TaskSchedulerWithDb.Starter;

// import org.springframework.boot.context.event.ApplicationReadyEvent;
// import org.springframework.context.event.EventListener;
// import org.springframework.stereotype.Component;

// import com.respapis.respApisCleint.TaskSchedulerWithDb.service.DynamicTaskService;

// @Component
// public class TaskInitializer {

//     private final DynamicTaskService taskService;

//     public TaskInitializer(DynamicTaskService taskService) {
//         this.taskService = taskService;
//     }

//     @EventListener(ApplicationReadyEvent.class)
//     public void initializeTasks() {
//         taskService.loadTasksFromDatabase();
//     }
// }
