package Acleda.com.kh.CronJob.TaskSchedulerWithDb.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ScheduledTaskRepository extends JpaRepository<ScheduledTask, Long> {
    Optional<ScheduledTask> findByTaskId(String taskId);
    List<ScheduledTask> findByActiveTrue();
}
