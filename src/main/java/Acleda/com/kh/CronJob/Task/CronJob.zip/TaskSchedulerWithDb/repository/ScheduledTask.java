package Acleda.com.kh.CronJob.TaskSchedulerWithDb.repository;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "scheduled_tasks")
public class ScheduledTask {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "task_id", nullable = false, unique = true)
    private String taskId;

    @Column(name = "service_name", nullable = false)
    private String serviceName;

    @Column(name = "cron_expression", nullable = false)
    private String cronExpression;

    @Column(name = "active", nullable = false)
    private boolean active = true;

    // Getters and Setters
}
