package Acleda.com.kh.CronJob.Task.repository.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "scheduled_tasks")
public class ScheduledTask {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String cronExpression; // Stores the cron expression
    private boolean active; // True if the task is running
    private String status; // "PENDING", "RUNNING", "COMPLETED"
    private LocalDateTime lastRunTime;

}
