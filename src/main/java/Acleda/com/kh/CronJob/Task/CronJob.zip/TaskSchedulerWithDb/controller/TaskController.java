package Acleda.com.kh.CronJob.TaskSchedulerWithDb.controller;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Acleda.com.kh.CronJob.Task.repository.ScheduledTaskRepository;
import Acleda.com.kh.CronJob.Task.repository.entity.ScheduledTask;
import Acleda.com.kh.CronJob.TaskSchedulerWithDb.service.DynamicTaskService;



@RestController
@RequestMapping("/tasks")
public class TaskController {

    private final ScheduledTaskRepository repository;
    private final DynamicTaskService taskService;

    public TaskController(ScheduledTaskRepository repository, DynamicTaskService taskService) {
        this.repository = repository;
        this.taskService = taskService;
    }

    @PostMapping("/add")
    public ResponseEntity<String> addTask(@RequestBody ScheduledTask task) {
        repository.save(task);
        taskService.updateTask(task);
        return ResponseEntity.ok("Task added: " + task.getTaskId());
    }

    @PutMapping("/update/{taskId}")
    public ResponseEntity<String> updateTask(@PathVariable String taskId, @RequestBody ScheduledTask task) {
        ScheduledTask existingTask = repository.findByTaskId(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));
        existingTask.setServiceName(task.getServiceName());
        existingTask.setCronExpression(task.getCronExpression());
        existingTask.setActive(task.isActive());
        repository.save(existingTask);
        taskService.updateTask(existingTask);
        return ResponseEntity.ok("Task updated: " + taskId);
    }

    @DeleteMapping("/remove/{taskId}")
    public ResponseEntity<String> removeTask(@PathVariable String taskId) {
        ScheduledTask task = repository.findByTaskId(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));
        taskService.cancelTask(taskId);
        repository.delete(task);
        return ResponseEntity.ok("Task removed: " + taskId);
    }
}
