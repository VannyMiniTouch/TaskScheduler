package Acleda.com.kh.CronJob.TaskSchedulerWithDb.service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;

import javax.imageio.spi.ServiceRegistry;

import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;

import Acleda.com.kh.CronJob.Task.repository.ScheduledTaskRepository;



@Service
public class DynamicTaskService {

    private final TaskScheduler taskScheduler;
    private final ScheduledTaskRepository repository;
    private final ServiceRegistry serviceRegistry; // Assume this maps service names to Runnables
    private final Map<String, ScheduledFuture<?>> tasks = new ConcurrentHashMap<>();

    public DynamicTaskService(TaskScheduler taskScheduler, 
                              ScheduledTaskRepository repository,
                              ServiceRegistry serviceRegistry) {
        this.taskScheduler = taskScheduler;
        this.repository = repository;
        this.serviceRegistry = serviceRegistry;
    }

    public void loadTasksFromDatabase() {
        repository.findByActiveTrue().forEach(task -> {
            Runnable runnable = serviceRegistry.getService(task.getServiceName());
            if (runnable != null) {
                scheduleTask(task.getTaskId(), runnable, task.getCronExpression());
            }
        });
    }

    public void scheduleTask(String taskId, Runnable task, String cronExpression) {
        cancelTask(taskId); // Avoid duplicates
        CronTrigger cronTrigger = new CronTrigger(cronExpression);
        ScheduledFuture<?> scheduledTask = taskScheduler.schedule(task, cronTrigger);
        tasks.put(taskId, scheduledTask);
    }

    public void cancelTask(String taskId) {
        ScheduledFuture<?> scheduledTask = tasks.get(taskId);
        if (scheduledTask != null) {
            scheduledTask.cancel(true);
            tasks.remove(taskId);
        }
    }

    public void updateTask(ScheduledTask dbTask) {
        Runnable task = serviceRegistry.getService(dbTask.getServiceName());
        if (task != null) {
            scheduleTask(dbTask.getTaskId(), task, dbTask.getCronExpression());
        }
    }
}
